public interface Addible<T> {
    void add(T var1);

    boolean removable();
}

